# Snapshot Helm Chart

> Experimental feature. The agent runs as a privileged DaemonSet to perform
> CRIU checkpoint and restore operations.

This chart installs the snapshot infrastructure:

- the operator Deployment that reconciles `SnapshotJob`, `PodSnapshot`, and
  `PodSnapshotContent`
- the agent DaemonSet on eligible GPU nodes
- `snapshot-pvc`, or wiring to an existing PVC
- cluster-scoped agent and operator RBAC
- the seccomp profile CRIU needs

Install one Snapshot release for the cluster. Every node agent mounts the same
shared checkpoint PVC directly and watches checkpoint/restore pods in all
namespaces. Workload pods never mount checkpoint storage.

## Prerequisites

- Kubernetes cluster with x86_64 or arm64 GPU nodes
- NVIDIA GPU Operator 26.3 or newer, with NVIDIA driver 580.xx or newer
- **containerd** or **CRI-O** (chart defaults to containerd; see below for CRI-O / OpenShift)
- a cluster where a privileged DaemonSet with `hostPID`, `hostIPC`, and `hostNetwork` is acceptable

The checkpoint PVC must support `ReadWriteMany` because agents on multiple nodes
mount it concurrently. Chart-created claims always request `ReadWriteMany` and
are retained when the Helm release is removed.

An existing `ReadWriteOnce` claim cannot be upgraded in place because PVC access
modes are immutable. When `storage.pvc.create=false`, the chart assumes the named
existing claim supports `ReadWriteMany`; verify its access mode before installing
or upgrading. To migrate, create a new RWX claim, copy the retained checkpoint
data once if it must be preserved, then set `storage.pvc.create=false` and
`storage.pvc.name` to the new claim. The old retained claim remains untouched.

When using AWS EFS, make sure a reused static PV references a real EFS file
system ID and has mount targets reachable from every GPU node. A placeholder
such as `fs-xxxx` can bind a PVC but the snapshot agent will not start because
the node cannot mount it.

## OpenShift installation

OpenShift uses CRI-O. Install with `runtime.type=crio` and
`openshift.enabled=true`. The OpenShift setting creates the SCC-use RBAC and
required-SCC pod annotations for both components: the agent uses the
`privileged` SCC and the operator uses `anyuid`. Keep `rbac.create=true` (the
default); otherwise, create equivalent SCC-use RBAC separately. The agent uses
public GHCR images by default and does not need an image pull secret; configure
`daemonset.imagePullSecrets` only for a private image override. When upgrading a
release that uses a private agent image, set the private registry pull secret in
the same Helm upgrade so the new chart defaults do not remove the required image
access.

Create a checkpoint PVC through an RWX-capable StorageClass, such as an EFS
StorageClass:

```bash
export RWX_STORAGE_CLASS=efs-rwx

helm upgrade --install snapshot ./charts/snapshot \
  --namespace "${NAMESPACE}" --create-namespace \
  --set storage.pvc.create=true \
  --set storage.pvc.storageClass="${RWX_STORAGE_CLASS}" \
  --set runtime.type=crio \
  --set openshift.enabled=true
```

Or reuse an existing RWX PVC in the installation namespace:

```bash
export EXISTING_RWX_PVC=snapshot-efs-pvc

helm upgrade --install snapshot ./charts/snapshot \
  --namespace "${NAMESPACE}" --create-namespace \
  --set storage.pvc.create=false \
  --set storage.pvc.name="${EXISTING_RWX_PVC}" \
  --set runtime.type=crio \
  --set openshift.enabled=true
```

## RKE2 and k3s

RKE2 and k3s relocate both the CRI socket and containerd's snapshotter storage,
so set both values together:

```bash
helm upgrade --install snapshot ./charts/snapshot \
  --namespace "${NAMESPACE}" --create-namespace \
  --set runtime.socketPath=/run/k3s/containerd/containerd.sock \
  --set runtime.storageDir=/var/lib/rancher/rke2/agent/containerd
```

For k3s use `--set runtime.storageDir=/var/lib/rancher/k3s/agent/containerd`.

`runtime.storageDir` is mounted into the agent container at the identical
absolute path it has on the host. The agent tars the overlay `upperDir` read
verbatim out of containerd's own metadata, so the path must resolve unchanged
inside the agent's mount namespace — it is not a relocatable prefix.

## Minimal install

Create the checkpoint PVC and the agent:

```bash
helm upgrade --install snapshot ./charts/snapshot \
  --namespace ${NAMESPACE} \
  --create-namespace \
  --set storage.pvc.create=true
```

If your cluster does not use a default storage class, also set
`storage.pvc.storageClass`.

Reuse an existing PVC instead:

```bash
helm upgrade --install snapshot ./charts/snapshot \
  --namespace ${NAMESPACE} \
  --create-namespace \
  --set storage.pvc.create=false \
  --set storage.pvc.name=my-snapshot-pvc
```

## CRD upgrades

Helm creates the CRDs in [crds/](./crds) on a fresh install and then leaves them
alone: `helm upgrade` never updates them. To close that gap the operator
Deployment runs a `crd-installer` init container before the manager starts. It
server-side applies the CRDs embedded in the `api` module — the same manifests
`make generate` mirrors into `crds/` — so every rollout converges the cluster on
definitions the running binary agrees with. Nothing to update means nothing is
written:

```bash
kubectl logs deployment/snapshot-operator -n ${NAMESPACE} -c crd-installer
```

```text
Applied CRD  {"name": "podsnapshots.nvidia.com", "action": "unchanged"}
Applied CRD  {"name": "podsnapshotcontents.nvidia.com", "action": "unchanged"}
Applied CRD  {"name": "snapshotjobs.nvidia.com", "action": "unchanged"}
CRDs already up to date, no changes applied  {"count": 3}
```

The installer runs whenever the operator pod is recreated, which a `helm upgrade`
does as soon as the image tag moves — `image.operator.tag` defaults to the
chart's `appVersion`, so a release that changes the CRDs changes the tag too. If
you pin a mutable tag such as `latest`, rebuilding it does not change the pod
spec and nothing rolls; restart the Deployment yourself to pick up new
definitions.

`rbac.create=true` grants the operator ServiceAccount `get`/`patch` on the three
CRDs in [crds/](./crds) by name, plus an unscoped `create` — RBAC cannot match
`resourceNames` on create, so that verb only ever lets the operator add a CRD,
never modify one it does not own.

Set `crdUpgrade.enabled=false` when CRDs are managed out of band, for example by
GitOps or by a cluster admin who does not want the operator holding
`apiextensions` permissions. That drops the init container and the extra RBAC —
and makes updating the CRDs your responsibility after every chart upgrade:

```bash
kubectl apply --server-side --force-conflicts -f ./charts/snapshot/crds/
```

## Verify

```bash
PVC_NAME="${PVC_NAME:-snapshot-pvc}" # match storage.pvc.name
kubectl get pvc "${PVC_NAME}" -n "${NAMESPACE}"
kubectl rollout status daemonset/snapshot-agent -n ${NAMESPACE}
kubectl get pods -n ${NAMESPACE} -l app.kubernetes.io/name=snapshot -o wide
```

## Important values

| Parameter | Meaning | Default |
|-----------|---------|---------|
| `image.operator.repository` | Operator image repository | `ghcr.io/ai-dynamo/snapshot/operator` |
| `image.agent.repository` | Agent image repository | `ghcr.io/ai-dynamo/snapshot/agent` |
| `image.agent.tag` | Agent and PageBroker image tag (empty = chart appVersion) | `""` |
| `image.pageBroker.repository` | PageBroker sidecar image repository. Always pulled at `image.agent.tag` | `ghcr.io/ai-dynamo/snapshot/pagebroker` |
| `pageBroker.transferBufferCount` | Persistent transfer slots per visible GPU | `32` |
| `pageBroker.transferChunkBytes` | Bytes per transfer slot | `134217728` |
| `pageBroker.maxPinnedBytes` | Total pinned memory limit, including allocation rounding. Zero sets no limit | `0` |
| `daemonset.imagePullSecrets` | Pull secrets for a private agent image override | `[]` |
| `daemonset.runtimeClassName` | RuntimeClass for the agent pod. Set `""` to omit it when the NVIDIA runtime is containerd's default and no `nvidia` RuntimeClass exists | `nvidia` |
| `operator.resources` | CPU and memory requests/limits for the operator manager | 50m CPU / 64Mi request, 500m CPU / 256Mi limit |
| `operator.nodeSelector` | Node selector for the operator pod | `{}` |
| `operator.affinity` | Affinity rules for the operator pod | `{}` |
| `operator.tolerations` | Tolerations for the operator pod | `[]` |
| `storage.type` | Snapshot-owned storage backend | `pvc` |
| `storage.pvc.create` | Create `snapshot-pvc` instead of using an existing shared PVC | `true` |
| `storage.pvc.name` | Shared RWX checkpoint PVC mounted by every agent | `snapshot-pvc` |
| `storage.pvc.size` | Requested PVC size | `1Ti` |
| `storage.pvc.storageClass` | Storage class name | `""` |
| `storage.pvc.basePath` | Fixed checkpoint mount path enforced by the privileged helper | `/checkpoints` |
| `pageBroker.staging.sizeLimit` | Cap on the memory-backed staging volume shared by the agent and PageBroker, used for checkpoint (except GPU CustomStorage capture) and staged restore. Leave headroom above it in the writing container's memory limit; the chart's 64Gi default and the agent's 64Gi default memory limit leave none | `64Gi` |
| `pageBroker.maxConcurrentRequests` | Concurrent control-socket requests the daemon serves | `16` |
| `pageBroker.resources` | CPU and memory requests/limits for the PageBroker sidecar. The memory limit bounds restore prefetch into staging | 8 CPU / 32Gi request, 32 CPU / 256Gi limit |
| `daemonset.resources` | CPU and memory requests/limits for the agent. The agent's memory limit also bounds the largest checkpoint image, because CRIU writes it into memory-backed PageBroker staging (direct GPU CustomStorage capture writes to the PVC instead, and is not bound by this) | 2 CPU / 1Gi request, 4 CPU / 64Gi limit |
| `seccomp.deploy` | Deploy the CRIU seccomp profile ConfigMap and init container. Use this field name; `seccomp.enabled` is not a chart value | `true` |
| `runtime.type` | CRI backend: `containerd` or `crio` | `containerd` |
| `runtime.socketPath` | CRI socket (empty = default for `runtime.type`) | `""` |
| `runtime.storageDir` | Host per-container storage dir, mounted at the identical path in the agent (empty = default for `runtime.type`) | `""` |
| `crdUpgrade.enabled` | Install and upgrade the CRDs from an operator init container (see below) | `true` |
| `crdUpgrade.logLevel` | Init container log level | `info` |
| `rbac.create` | Create agent and operator RBAC | `true` |
| `openshift.enabled` | Create required-SCC pod annotations and, when `rbac.create=true`, OpenShift SCC-use RBAC | `false` |

Reserved `s3` and `oci` values remain chart-owned placeholders for future
snapshot backends, but only `pvc` is implemented today.

PageBroker handles every capture and restore. GPU capture uses CustomStorage
when the driver supports it, otherwise it uses the driver-managed format.
Restore follows the saved artifact format.

PageBroker adds an 8 CPU and 32 GiB memory request to each agent pod. A node
must have this capacity plus the agent's own request, or the pod stays Pending.
Set `pageBroker.resources` for the node profile. The default transfer rings reserve 4 GiB per
GPU, or 32 GiB on an eight-GPU node, plus overhead. A lower resource request
does not reduce this allocation. Set the memory limit to cover the rings,
process memory, and CPU staging. See the
[engine design](../../docs/proposals/238-pagebroker-gpu-engine/README.md).

See [values.yaml](./values.yaml) for the full configuration surface.

## Uninstall

```bash
helm uninstall snapshot -n ${NAMESPACE}
```

The chart does not delete checkpoint data automatically. Remove the PVC yourself
if you want to clear stored checkpoints:

```bash
PVC_NAME="${PVC_NAME:-snapshot-pvc}" # match storage.pvc.name
kubectl delete pvc "${PVC_NAME}" -n "${NAMESPACE}"
```

## Notice and disclaimer

Installing this chart causes your cluster to retrieve container images that are
not distributed with the chart, including the `busybox` image used as a
short-lived init container to write the seccomp profile (overridable via
`daemonset.initContainer.image`).

> **NOTICE AND DISCLAIMER:** This software automatically retrieves, accesses or
> interacts with external materials. Those retrieved materials are not
> distributed with this software and are governed solely by separate terms,
> conditions and licenses. You are solely responsible for finding, reviewing and
> complying with all applicable terms, conditions, and licenses, and for
> verifying the security, integrity and suitability of any retrieved materials
> for your specific use case. This software is provided "AS IS", without
> warranty of any kind. The author makes no representations or warranties
> regarding any retrieved materials, and assumes no liability for any losses,
> damages, liabilities or legal consequences from your use or inability to use
> this software or any retrieved materials. Use this software and the retrieved
> materials at your own risk.

Materials this chart causes to be retrieved:

| Image | Default reference | License | Retrieved from |
|---|---|---|---|
| Snapshot operator | `ghcr.io/ai-dynamo/snapshot/operator` | Apache-2.0 (NVIDIA) | GHCR |
| Snapshot agent | `ghcr.io/ai-dynamo/snapshot/agent` | Apache-2.0 (NVIDIA) | GHCR |
| Snapshot PageBroker | `ghcr.io/ai-dynamo/snapshot/pagebroker` | Apache-2.0 (NVIDIA) | GHCR |
| busybox init container | `busybox:1.37.0` (digest-pinned) | GPL-2.0 | Docker Hub |

Third-party attribution and corresponding source for the NVIDIA images are
shipped inside those images under `/legal/`.
